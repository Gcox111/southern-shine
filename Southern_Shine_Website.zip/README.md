# Southern Shine Mobile Detailing & Tint Website

## Publish it free with GitHub Pages

1. Create a free account at GitHub.com.
2. Create a new public repository named `southern-shine`.
3. Upload `index.html`, `styles.css`, `script.js`, and `logo.svg`.
4. Open the repository's **Settings**, then **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select the `main` branch and `/root`, then save.
7. GitHub will provide a free website address.

## Easy edits

- Phone number and text-booking links are in `index.html`.
- Prices and services are in the Pricing and Services sections.
- The main colors are in `styles.css`.
- Replace the recreated `logo.svg` with the original logo file at any time, keeping the filename `logo.svg`.

The site is mobile-friendly and includes click-to-call and prefilled text-message booking links.
